'use strict';

module.exports = {
  handler(event, context) {
    return 'Hello World';
  },
};
