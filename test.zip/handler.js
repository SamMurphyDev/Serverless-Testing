'use strict';

module.exports = {
  handler(event, context) {
    console.log('---Event---');
    console.log(event);
    console.log('---Context---');
    console.log(context);
    console.log('---End---');
    return {event, context};
  },
};
